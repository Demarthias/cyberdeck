#!/data/data/com.termux/files/usr/bin/bash
# venom@fire5 — cyberdeck edition
# add to ~/.bashrc:  source ~/cyberdeck/venom_prompt.sh

_DECK_DB="$HOME/cyberdeck/config/threats.db"
_DECK_CACHE=""
_DECK_CACHE_TIME=0

_deck_query() {
    local now
    now=$(date +%s)
    if (( now - _DECK_CACHE_TIME > 15 )); then
        if [[ -f "$_DECK_DB" ]]; then
            _DECK_CACHE=$(sqlite3 "$_DECK_DB" "
                SELECT
                  COALESCE(MAX(total_score), 0),
                  COALESCE(SUM(CASE WHEN blocked=1 THEN 1 ELSE 0 END), 0),
                  COALESCE(COUNT(*), 0)
                FROM threats
                WHERE total_score >= 1;
            " 2>/dev/null)
        else
            _DECK_CACHE="0|0|0"
        fi
        _DECK_CACHE_TIME=$now
    fi
    echo "$_DECK_CACHE"
}

_venom_prompt() {
    local exit_code=$?

    local raw top_score blocked total
    raw=$(_deck_query)
    top_score=$(echo "$raw" | cut -d'|' -f1)
    blocked=$(echo "$raw"   | cut -d'|' -f2)
    total=$(echo "$raw"     | cut -d'|' -f3)
    top_score=${top_score:-0}
    blocked=${blocked:-0}
    total=${total:-0}

    local ts online
    ts=$(tailscale status 2>/dev/null)
    online=$(echo "$ts" | grep -c "active" 2>/dev/null || echo 0)

    # threat bar
    local bar filled empty
    filled=$(( top_score > 10 ? 10 : top_score ))
    empty=$(( 10 - filled ))
    bar=""
    for (( i=0; i<filled; i++ )); do bar+="▓"; done
    for (( i=0; i<empty; i++ )); do bar+="░"; done

    # 3 tiers only
    local color
    if [[ $blocked -gt 0 || $top_score -ge 8 ]]; then
        color="\[\e[31m\]"        # red — bad
    elif [[ $top_score -ge 3 ]]; then
        color="\[\e[33m\]"        # yellow — moderate
    else
        color="\[\e[32m\]"        # green — good
    fi

    # command dot
    local dot
    if [[ $exit_code -eq 0 ]]; then
        dot="\[\e[32m\]●\[\e[0m\]"
    else
        dot="\[\e[31m\]●\[\e[0m\]"
    fi

    local R="\[\e[0m\]"
    local C="\[\e[36;1m\]"
    local M="\[\e[35;1m\]"
    local DIM="\[\e[2m\]"

    PS1="${color}(${top_score})-threatscore${R} ${C}venom${R}@${M}fire5${R} ${dot}\n"
    PS1+="${color}${bar}${R} ${DIM}${total} tracked · ${blocked} blocked · ${online} peers${R}\n"
    PS1+="\$ "
}

PROMPT_COMMAND="_venom_prompt"
