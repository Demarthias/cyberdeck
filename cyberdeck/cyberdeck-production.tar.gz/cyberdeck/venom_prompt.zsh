# venom@fire5 — cyberdeck edition (ZSH)
# add to ~/.zshrc:  source ~/cyberdeck/venom_prompt.zsh

autoload -U colors && colors

_DECK_DB="$HOME/cyberdeck/config/threats.db"
_DECK_CACHE=""
_DECK_CACHE_TIME=0

_deck_query() {
    local now
    now=$(date +%s)
    if (( now - _DECK_CACHE_TIME > 15 )); then
        if [[ -f "$_DECK_DB" ]]; then
            _DECK_CACHE=$(sqlite3 "$_DECK_DB" "
                SELECT
                  COALESCE(MAX(total_score), 0),
                  COALESCE(SUM(CASE WHEN blocked=1 THEN 1 ELSE 0 END), 0),
                  COALESCE(COUNT(*), 0)
                FROM threats
                WHERE total_score >= 1;
            " 2>/dev/null)
        else
            _DECK_CACHE="0|0|0"
        fi
        _DECK_CACHE_TIME=$now
    fi
    echo "$_DECK_CACHE"
}

precmd() {
    local exit_code=$?

    local raw top_score blocked total
    raw=$(_deck_query)
    top_score=$(echo "$raw" | cut -d'|' -f1)
    blocked=$(echo "$raw"   | cut -d'|' -f2)
    total=$(echo "$raw"     | cut -d'|' -f3)
    top_score=${top_score:-0}
    blocked=${blocked:-0}
    total=${total:-0}

    local ts online
    ts=$(tailscale status 2>/dev/null)
    online=$(echo "$ts" | grep -c "active" 2>/dev/null || echo 0)

    # threat bar
    local bar filled empty i
    filled=$(( top_score > 10 ? 10 : top_score ))
    empty=$(( 10 - filled ))
    bar=""
    for (( i=0; i<filled; i++ )); do bar+="▓"; done
    for (( i=0; i<empty; i++ )); do bar+="░"; done

    # 3 tiers
    local color
    if [[ $blocked -gt 0 || $top_score -ge 8 ]]; then
        color="%F{red}"
    elif [[ $top_score -ge 3 ]]; then
        color="%F{yellow}"
    else
        color="%F{green}"
    fi

    # command dot
    local dot
    if [[ $exit_code -eq 0 ]]; then
        dot="%F{green}●%f"
    else
        dot="%F{red}●%f"
    fi

    PROMPT="${color}(${top_score})-threatscore%f %F{cyan}%Bvenom%b%f@%F{magenta}%Bfire5%b%f ${dot}
${color}${bar}%f %F{240}${total} tracked · ${blocked} blocked · ${online} peers%f
%# "
}
